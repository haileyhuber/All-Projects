package LinkedListA0;

public interface LIST_Interface {
	
	public boolean insert(Node n, int index);
    public boolean remove(int index);
    public Node get(int index);
    public int size();
    public boolean isEmpty();
    public void clear();

}
